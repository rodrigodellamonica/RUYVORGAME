package com.ruyvor.game

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private var gv: GameView? = null
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val et = EditText(this).apply { hint = "Nome do seu personagem" }
        AlertDialog.Builder(this).setTitle("Crie seu personagem").setView(et).setCancelable(false)
            .setPositiveButton("Continuar") { _, _ ->
                val nome = et.text.toString().ifBlank { "Jogador" }
                AlertDialog.Builder(this).setTitle("Escolha sua carreira").setCancelable(false)
                    .setItems(CARREIRAS.map { it.nome }.toTypedArray()) { _, i -> start(nome, CARREIRAS[i]) }
                    .show()
            }.show()
    }

    private fun start(nome: String, c: Career) {
        val root = FrameLayout(this)
        val tv = TextView(this).apply { setTextColor(-1); textSize = 14f; setPadding(24, 16, 24, 16); setBackgroundColor(0x66000000) }
        val g = GameView(this, c, nome) { s -> runOnUiThread { tv.text = s } }
        val btn = Button(this).apply { text = "ENTRAR / SAIR DO CARRO"; setOnClickListener { g.toggleCar() } }
        root.addView(g)
        root.addView(tv)
        root.addView(btn, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        setContentView(root)
        gv = g
    }
    override fun onPause() { super.onPause(); gv?.onPause() }
    override fun onResume() { super.onResume(); gv?.onResume() }
}

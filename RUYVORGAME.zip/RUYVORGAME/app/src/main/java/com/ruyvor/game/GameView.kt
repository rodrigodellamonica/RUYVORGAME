package com.ruyvor.game

import android.content.Context
import android.opengl.GLES20.*
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*
import kotlin.random.Random

class Career(val nome: String, val tarefa: String, val pago: Int, val cor: FloatArray)

val CARREIRAS = listOf(
    Career("Policial", "Atender ocorrência", 300, floatArrayOf(.15f, .3f, 1f)),
    Career("Médico", "Atender paciente", 450, floatArrayOf(.95f, .95f, .95f)),
    Career("Piloto", "Chegar ao aeroporto", 600, floatArrayOf(.2f, .2f, .3f)),
    Career("Empresário", "Fechar negócio", 800, floatArrayOf(.1f, .1f, .1f)),
    Career("Motorista", "Corrida de passageiro", 250, floatArrayOf(.9f, .8f, .1f)),
    Career("Mecânico", "Consertar carro", 280, floatArrayOf(.9f, .4f, .1f)),
    Career("Chef", "Entregar pedido", 220, floatArrayOf(.9f, .9f, .8f)),
    Career("Músico", "Show na cidade", 500, floatArrayOf(.7f, .1f, .8f)),
    Career("Bombeiro", "Combater incêndio", 350, floatArrayOf(.9f, .1f, .1f)),
    Career("Criminoso", "Golpe na cidade", 900, floatArrayOf(.25f, .25f, .25f))
)

class GameView(c: Context, val car: Career, val nome: String, val hud: (String) -> Unit) :
    GLSurfaceView(c), GLSurfaceView.Renderer {

    private val P = 56f
    private var px = 28f; private var pz = 28f; private var yaw = 0f
    private var carX = 34f; private var carZ = 28f; private var carYaw = 0f; private var spd = 0f
    @Volatile private var inCar = false
    private var mx = 0f; private var mz = 0f
    private var money = 0; private var done = 0
    private var tx = 0f; private var tz = 0f
    private var t = 100f; private var last = 0L; private var fr = 0
    private val rnd = Random(7)
    private val H = FloatArray(81) { 14f + rnd.nextFloat() * 55f }
    private val sx = FloatArray(12); private val sy = FloatArray(12); private val lx = FloatArray(12)
    private val proj = FloatArray(16); private val view = FloatArray(16); private val vp = FloatArray(16)
    private val m = FloatArray(16); private val m2 = FloatArray(16); private val r = FloatArray(16); private val mvp = FloatArray(16)
    private var prog = 0
    private lateinit var vb: java.nio.FloatBuffer
    private var sun = 1f

    init { setEGLContextClientVersion(2); setRenderer(this); newMission() }

    fun toggleCar() {
        if (inCar) { inCar = false; px = carX + 3f; pz = carZ; spd = 0f }
        else if (hypot(px - carX, pz - carZ) < 8f) inCar = true
    }

    private fun newMission() { tx = 28f + P * Random.nextInt(-4, 4); tz = 28f + P * Random.nextInt(-4, 4) }
    private fun blocked(x: Float, z: Float): Boolean {
        if (abs(x) > 4 * P + 18 || abs(z) > 4 * P + 18) return true
        val a = ((x % P) + P) % P; val b = ((z % P) + P) % P
        return min(a, P - a) < 18f && min(b, P - b) < 18f
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val i = e.actionIndex; val id = e.getPointerId(i)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> { sx[id] = e.getX(i); sy[id] = e.getY(i); lx[id] = e.getX(i) }
            MotionEvent.ACTION_MOVE -> for (k in 0 until e.pointerCount) {
                val p = e.getPointerId(k)
                if (sx[p] < width / 2f) { mx = ((e.getX(k) - sx[p]) / 150f).coerceIn(-1f, 1f); mz = ((e.getY(k) - sy[p]) / 150f).coerceIn(-1f, 1f) }
                else { if (!inCar) yaw += (e.getX(k) - lx[p]) * 0.006f; lx[p] = e.getX(k) }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> if (sx[id] < width / 2f) { mx = 0f; mz = 0f }
        }
        return true
    }

    override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) {
        val d = ArrayList<Float>()
        for (a in 0..2) for (s in listOf(-1f, 1f)) {
            val u = (a + 1) % 3; val v = (a + 2) % 3
            for ((i, j) in listOf(-1 to -1, 1 to -1, 1 to 1, -1 to -1, 1 to 1, -1 to 1)) {
                val p = FloatArray(3); p[a] = .5f * s; p[u] = .5f * i; p[v] = .5f * j
                val n = FloatArray(3); n[a] = s
                d.addAll(p.toList()); d.addAll(n.toList())
            }
        }
        vb = ByteBuffer.allocateDirect(d.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(d.toFloatArray()); position(0) }
        val vs = "attribute vec3 aP;attribute vec3 aN;uniform mat4 uMVP;uniform mat4 uM;uniform mat4 uR;varying vec3 vN;varying vec3 vP;varying float vD;" +
            "void main(){vec4 w=uM*vec4(aP,1.);vP=w.xyz;vN=(uR*vec4(aN,0.)).xyz;gl_Position=uMVP*vec4(aP,1.);vD=gl_Position.w;}"
        val fs = "precision mediump float;uniform vec3 uC;uniform vec3 uSky;uniform float uSun;uniform float uWin;uniform float uEmit;varying vec3 vN;varying vec3 vP;varying float vD;" +
            "void main(){vec3 L=normalize(vec3(.4,.8,.3));float l=max(dot(normalize(vN),L),0.)*uSun+.25*uSun+.08;vec3 c=uC*l;" +
            "if(uWin>.5&&abs(vN.y)<.5){float w=step(fract(vP.y*.2),.55)*step(fract((vP.x+vP.z)*.2),.55);c=mix(c,vec3(1.,.85,.5)*(1.1-uSun),w*.8);}" +
            "if(uEmit>.5)c=uC;c=mix(c,uSky,clamp(vD/380.,0.,1.));gl_FragColor=vec4(c,1.);}"
        prog = glCreateProgram()
        for ((ty, src) in listOf(GL_VERTEX_SHADER to vs, GL_FRAGMENT_SHADER to fs)) {
            val s = glCreateShader(ty); glShaderSource(s, src); glCompileShader(s); glAttachShader(prog, s)
        }
        glLinkProgram(prog); glUseProgram(prog); glEnable(GL_DEPTH_TEST)
    }

    override fun onSurfaceChanged(g: GL10?, w: Int, h: Int) {
        glViewport(0, 0, w, h); Matrix.perspectiveM(proj, 0, 60f, w.toFloat() / h, 0.3f, 500f)
    }

    private fun box(x: Float, y: Float, z: Float, w: Float, h: Float, d: Float, ya: Float, col: FloatArray, win: Float = 0f, emit: Float = 0f) {
        Matrix.setIdentityM(r, 0); Matrix.rotateM(r, 0, -ya * 57.2958f, 0f, 1f, 0f)
        Matrix.setIdentityM(m, 0); Matrix.translateM(m, 0, x, y, z); Matrix.multiplyMM(m2, 0, m, 0, r, 0)
        Matrix.scaleM(m2, 0, w, h, d); Matrix.multiplyMM(mvp, 0, vp, 0, m2, 0)
        glUniformMatrix4fv(glGetUniformLocation(prog, "uMVP"), 1, false, mvp, 0)
        glUniformMatrix4fv(glGetUniformLocation(prog, "uM"), 1, false, m2, 0)
        glUniformMatrix4fv(glGetUniformLocation(prog, "uR"), 1, false, r, 0)
        glUniform3fv(glGetUniformLocation(prog, "uC"), 1, col, 0)
        glUniform1f(glGetUniformLocation(prog, "uWin"), win); glUniform1f(glGetUniformLocation(prog, "uEmit"), emit)
        val ap = glGetAttribLocation(prog, "aP"); val an = glGetAttribLocation(prog, "aN")
        vb.position(0); glVertexAttribPointer(ap, 3, GL_FLOAT, false, 24, vb); glEnableVertexAttribArray(ap)
        vb.position(3); glVertexAttribPointer(an, 3, GL_FLOAT, false, 24, vb); glEnableVertexAttribArray(an)
        glDrawArrays(GL_TRIANGLES, 0, 36)
    }

    private fun update(dt: Float) {
        t += dt; sun = (0.55f + 0.5f * sin(t * 0.04f)).coerceIn(0.12f, 1f)
        if (inCar) {
            spd += ((-mz * 28f) - spd) * min(1f, dt * 1.5f)
            carYaw += mx * dt * 1.7f * (spd / 20f).coerceIn(-1f, 1f)
            val nx = carX + sin(carYaw) * spd * dt; val nz = carZ - cos(carYaw) * spd * dt
            if (!blocked(nx, nz)) { carX = nx; carZ = nz } else spd = 0f
            px = carX; pz = carZ; yaw += (carYaw - yaw) * min(1f, dt * 3f)
        } else {
            val f = -mz; val s = mx
            val nx = px + (sin(yaw) * f + cos(yaw) * s) * 7f * dt
            val nz = pz + (-cos(yaw) * f + sin(yaw) * s) * 7f * dt
            if (!blocked(nx, pz)) px = nx; if (!blocked(px, nz)) pz = nz
        }
        if (hypot(px - tx, pz - tz) < 6f) { money += car.pago; done++; newMission() }
        if (++fr % 10 == 0) hud("$nome • ${car.nome}   R$ $money   Missões: $done\n${car.tarefa}: ${hypot(px - tx, pz - tz).toInt()} m")
    }

    override fun onDrawFrame(g: GL10?) {
        val now = System.nanoTime(); val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceAtMost(0.05f); last = now
        update(dt)
        val day = floatArrayOf(.55f, .75f, .95f); val night = floatArrayOf(.02f, .03f, .08f)
        val sky = FloatArray(3) { night[it] + (day[it] - night[it]) * sun }
        glClearColor(sky[0], sky[1], sky[2], 1f); glClear(GL_COLOR_BUFFER_BIT or GL_DEPTH_BUFFER_BIT)
        glUniform3fv(glGetUniformLocation(prog, "uSky"), 1, sky, 0); glUniform1f(glGetUniformLocation(prog, "uSun"), sun)
        val fx = sin(yaw); val fz = -cos(yaw); val dist = if (inCar) 11f else 6f
        Matrix.setLookAtM(view, 0, px - fx * dist, if (inCar) 5f else 3.5f, pz - fz * dist, px, 1.5f, pz, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        box(0f, -0.5f, 0f, 900f, 1f, 900f, 0f, floatArrayOf(.12f, .12f, .13f))
        for (gx in -4..4) for (gz in -4..4) {
            val h = H[(gx + 4) * 9 + gz + 4]; val cx = gx * P; val cz = gz * P
            box(cx, 0.15f, cz, 40f, .3f, 40f, 0f, floatArrayOf(.45f, .45f, .47f))
            val k = 0.3f + 0.3f * ((gx * 7 + gz * 3 + 20) % 5) / 5f
            box(cx, h / 2, cz, 34f, h, 34f, 0f, floatArrayOf(k, k + .03f, k + .08f), 1f)
        }
        box(tx, 30f, tz, 3f, 60f, 3f, 0f, floatArrayOf(car.cor[0], car.cor[1], car.cor[2]), 0f, 1f)
        for (i in 0 until 8) {
            val z = 28f + P * ((i % 5) - 2); val x = ((t * 10f + i * 61f) % 500f) - 250f
            box(x, .6f, z, 4.4f, 1.2f, 2.2f, Math.PI.toFloat() / 2f, floatArrayOf(.3f + i * .08f, .2f, .5f - i * .05f))
        }
        carBody(carX, carZ, carYaw)
        if (!inCar) {
            box(px, .45f, pz, .5f, .9f, .4f, yaw, floatArrayOf(.1f, .1f, .35f))
            box(px, 1.3f, pz, .6f, .7f, .35f, yaw, car.cor)
            box(px, 1.85f, pz, .35f, .35f, .35f, yaw, floatArrayOf(.9f, .7f, .55f))
        }
    }

    private fun carBody(x: Float, z: Float, y: Float) {
        box(x, .7f, z, 2.2f, .9f, 4.4f, y, floatArrayOf(.8f, .05f, .05f))
        box(x, 1.5f, z, 1.8f, .7f, 2.2f, y, floatArrayOf(.1f, .12f, .15f))
    }
}
